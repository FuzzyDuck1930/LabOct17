import { Clothes } from '../types/clothing';

class Dress {
        get(): Clothes[] {
        return [
            {
                hair: "https://github.com/FuzzyDuck1930/helpme/blob/main/-skeleton--boy-wuuuu1.png?raw=true",
                top: "https://github.com/FuzzyDuck1930/helpme/blob/main/-skeleton--boy-wuuuu2.png?raw=true",
                bottom: "https://github.com/FuzzyDuck1930/helpme/blob/main/-skeleton--boy-wuuuu3.png?raw=true",
            },

            {
                hair: "https://github.com/FuzzyDuck1930/helpme/blob/main/eboy-angel-blue-variant-wuuu1.png?raw=true",
                top: "https://github.com/FuzzyDuck1930/helpme/blob/main/eboy-angel-blue-variant-wuuu2.png?raw=true",
                bottom: "https://github.com/FuzzyDuck1930/helpme/blob/main/eboy-angel-blue-variant-wuuu3.png?raw=true",
            },

            {
                hair: "https://github.com/FuzzyDuck1930/helpme/blob/main/frog-todoroki-wuuu1.png?raw=true",
                top: "https://github.com/FuzzyDuck1930/helpme/blob/main/frog-todoroki-wuuu2.png?raw=true",
                bottom: "https://github.com/FuzzyDuck1930/helpme/blob/main/frog-todoroki-wuuu3.png?raw=true",
            },
        ];
    }
}

export default Dress;