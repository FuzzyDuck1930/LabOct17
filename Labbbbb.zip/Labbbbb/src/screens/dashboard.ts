import "../components/export"
import { addObserver, appState, dispatch } from '../store/index';

class Dashboard extends HTMLElement {
	constructor() {
		super();
		this.attachShadow({ mode: 'open' });
		addObserver(this);
	}

	connectedCallback() {
		this.render();
	}

	render() {
		if (this.shadowRoot) this.shadowRoot.innerHTML = '<link rel="stylesheet" href="styles.css">';
		const buttonprove = this.ownerDocument.createElement("the-cont");
		const stage = this.ownerDocument.createElement("div");
		stage.id = "Canvas";
		this.shadowRoot?.appendChild(buttonprove);
		this.shadowRoot?.appendChild(stage);
	}
}

customElements.define('app-dashboard', Dashboard);