import { AppState } from '../types/store';

import { Actions, ClothesActions } from '../types/store';

export const reducer = (currentAction: Actions, currentState: AppState): AppState => {
	const { action, payload } = currentAction;

	switch (action) {
		case ClothesActions.changeHair:
			return {
				...currentState,
				hair: payload,
			};

			case ClothesActions.changeTop:
			return {
				...currentState,
				top: payload,
			};

			case ClothesActions.changeBottom:
			return {
				...currentState,
				bottom: payload,
			};

		default:
			return currentState;
	}
};
