import { ClothesActions } from '../types/store';

export const changeTheHair = (payload: any) => {
	return {
		action: ClothesActions.changeHair,
		payload,
	};
};

export const changeTheTop = (payload: any) => {
	return {
		action: ClothesActions.changeTop,
		payload,
	};
};

export const changeTheBottom = (payload: any) => {
	return {
		action: ClothesActions.changeBottom,
		payload,
	};
};