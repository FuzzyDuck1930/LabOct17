import { AttributesButtons } from "../bttn/bttn";
import Dress from "../../services/clothing";

class line extends HTMLElement {

    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = ``
            const buttonRow1 = this.ownerDocument.createElement("div");
            const buttonRow2 = this.ownerDocument.createElement("div");
            const buttonRow3 = this.ownerDocument.createElement("div")

            const dressed = new Dress();
            const clothing = dressed.get();

            clothing.slice(0, 3).forEach((item) => {
                const theBtn = this.ownerDocument.createElement("the-bttn");
                theBtn.setAttribute(AttributesButtons.hair, item.hair);
                buttonRow1.appendChild(theBtn);
            });

            clothing.slice(0, 3).forEach ((item) => {
                const theBtn = this.ownerDocument.createElement("the-bttn");
                theBtn.setAttribute(AttributesButtons.top, item.top);
                buttonRow2.appendChild(theBtn);
            });

            clothing.slice(0, 3).forEach ((item) => {
                const theBtn = this.ownerDocument.createElement("the-bttn");
                theBtn.setAttribute(AttributesButtons.bottom, item.bottom);
                buttonRow3.appendChild(theBtn);
            });

            this.shadowRoot?.appendChild(buttonRow1);
            this.shadowRoot?.appendChild(buttonRow2);
            this.shadowRoot?.appendChild(buttonRow3);
        }
    }
}

customElements.define("the-line", line);
export default line;