export enum AttributesButtons {
    "hair" = "hair",
    "top" = "top",
    "bottom" = "bottom",
}

class bttn extends HTMLElement {
    hair?: string;
    top?: string;
    bottom?: string;

static get observedAttributes() {
    const attrs: Record<AttributesButtons , null> = {
        hair: null,
        top: null,
        bottom: null,
    };
    return Object.keys(attrs);
}

attributeChangedCallback(
    propName: AttributesButtons ,
    oldValue: string | undefined,
    newValue: string | undefined
    ) {
        switch (propName){
        default:
        this[propName] = newValue;
        break;
    }
    this.mount();
}

mount(){
    this.render();
    const btn = this.shadowRoot?.querySelector("button");
}

constructor(){
    super();
    this.attachShadow({mode: "open"});
}

connectedCallback(){
    this.render();
}

    render(){
            if (this.shadowRoot){
            this.shadowRoot.innerHTML = ``;
            const changeButton = this.ownerDocument.createElement("button")
            changeButton.classList.add("my-bttn")
            const imaButton = this.ownerDocument.createElement("img")
            imaButton.setAttribute("src", `${this.hair||this.top||this.bottom}`)
            changeButton.appendChild(imaButton);
            this.shadowRoot?.appendChild(changeButton);
        }
    }
}

customElements.define("the-bttn", bttn);
export default bttn;