import Clothes from '../../services/clothing';
import { line } from '../export';
import { AttributesButtons } from '../bttn/bttn';

class bigCont extends HTMLElement {

    constructor(){
        super();
        this.attachShadow({mode: "open"});
    }

    connectedCallback(){
        this.render();
    }

    render(){
        const allButtons = document.createElement("the-line");
        this.shadowRoot?.appendChild(allButtons);
    }
}

customElements.define("the-cont", bigCont);
export default bigCont;