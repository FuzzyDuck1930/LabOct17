export type Observer = { render: () => void } & HTMLElement;

export type AppState = {
	hair: string;
	top: string;
	bottom: string;
};

export enum ClothesActions {
	'changeHair' = 'changeHair',
	'changeTop' = 'changeTop',
	'changeBottom' = 'changeBottom',
}

export interface ChangeHairActions {
	action: ClothesActions.changeHair;
	payload: string;
}

export interface ChangeTopActions {
	action: ClothesActions.changeTop;
	payload: string;
}

export interface ChangeBottomActions {
	action: ClothesActions.changeBottom;
	payload: string;
}

export type Actions = ChangeHairActions | ChangeTopActions | ChangeBottomActions;