export interface Clothes {
    hair: string;
    top: string;
    bottom: string;
}